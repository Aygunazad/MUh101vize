#include<stdio.h>
int main()
{
	//while loop
	/*
	int i = 10;
	while(i >= 1)
	{
		printf("i: %d\n", i);
		i--;
	}*/
	
	//do while loop
	/*
	int j = 1;
	do{
	
		printf("j: %d\n", j);
		j++;
	}while(j <= 10);
	*/
	//for loop
	/*
	int k;
	for(k = 1; k <= 10; k++)
	{
		printf("k: %d\n", k);
		
	}
	*/
	//Write the C code that prints ‘Hello’ 5 times on the screen.

	/*
	int l;
	for(l = 1; l <= 5; l++)
	{
		printf("Hello\n");
	}*/
	//Write a C program that prints the sum of numbers from 1 to 10 on the screen.
    /*
    int c, sum = 0;
    
    for(c = 1; c <= 10; c++)
    {
    	sum = sum + c;	
	}
	printf("sum: %d\n", sum);
	printf("%d", c);
	*/
	//ASCII table
	int z;
	for(z = 1; z <= 256; z++)
	{
		printf("%d:%c\n",z,z);
	}
	
	
}